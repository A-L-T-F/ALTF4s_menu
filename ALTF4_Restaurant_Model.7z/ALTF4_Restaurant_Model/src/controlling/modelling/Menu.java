package controlling.modelling;
import java.util.ArrayList;
//import java.util.Date;

public class Menu extends Submenu{
	
	private ArrayList <Submenu> menu_list;

	public Menu() {
		// TODO Auto-generated constructor stub
	}

}
