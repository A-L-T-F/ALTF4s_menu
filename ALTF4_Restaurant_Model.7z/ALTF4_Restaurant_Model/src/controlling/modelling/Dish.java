package controlling.modelling;

public class Dish {
	private String name;
	private float price;
	private int size;

	public Dish() {
		// TODO Auto-generated constructor stub
	}

}
