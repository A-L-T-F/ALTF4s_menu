package controlling.modelling;

import java.util.ArrayList;
import java.util.Date;

public class Submenu {
	private String name;
	private String description;
	private Date current_date;
	private ArrayList <Dish> dishes;

	public Submenu() {
		// TODO Auto-generated constructor stub
	}

}
